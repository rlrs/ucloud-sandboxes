"""Compare blocking urllib3 with one aiohttp I/O loop behind the same HTTP handler."""
import asyncio,concurrent.futures,json,multiprocessing,os,sys,threading,time,statistics
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.request import Request

def pin(index):
 cpus=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,cpus[index:index+4])
def backend(pipe):
 pin(4)
 from aiohttp import web
 async def respond(req):
  body=await req.read();await asyncio.sleep(.01)
  return web.Response(body=b'{"ok":true}',content_type='application/json')
 async def run():
  app=web.Application();app.router.add_route('*','/{tail:.*}',respond)
  runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();pipe.send(site._server.sockets[0].getsockname()[1]);await asyncio.Event().wait()
 asyncio.run(run())

def io_process(conn):
 # Diagnostic prototype only: one trusted local IPC pipe, no retry or restart.
 from ucloud_sandboxes.node_http_async import AsyncNodeHttpPool
 pool=AsyncNodeHttpPool(control_connections=512)
 loop=pool._start()
 output_lock=threading.Lock()
 def done(ident,future):
  try:
   response=future.result();payload=(response.status,response.read());response.close()
  except BaseException as exc:payload=('error',type(exc).__name__)
  with output_lock:conn.send((ident,payload))
 while True:
  try:ident,url,data=conn.recv()
  except EOFError:
   pool.close();return
  future=asyncio.run_coroutine_threadsafe(pool._request('POST',url,{},data,10,3,1024,False),loop)
  future.add_done_callback(lambda f, ident=ident:done(ident,f))

class ProcessClient:
 def __init__(self,url):
  ctx=multiprocessing.get_context('spawn');self.conn,child=ctx.Pipe()
  self.child=ctx.Process(target=io_process,args=(child,),daemon=True);self.child.start();child.close()
  self.url=url;self.guard=threading.Lock();self.pending={};self.counter=0
  threading.Thread(target=self.receive,daemon=True).start()
 def receive(self):
  while True:
   ident,payload=self.conn.recv()
   with self.guard:future=self.pending.pop(ident)
   future.set_result(payload)
 def fetch(self,data):
  f=concurrent.futures.Future()
  with self.guard:
   self.counter+=1;ident=self.counter;self.pending[ident]=f
   self.conn.send((ident,self.url,data))
  status,body=f.result(timeout=30)
  assert status==200,(status,body)
  return body

def gateway(pipe,upstream,variant):
 pin(0)
 if variant in ('async-front','async-bridge','handler-bridge'):
  from aiohttp import web,ClientSession,TCPConnector
  async def serve():
   from ucloud_sandboxes.node_http_async import AsyncNodeHttpPool
   bridge=AsyncNodeHttpPool(control_connections=512)
   executor=concurrent.futures.ThreadPoolExecutor(max_workers=512)
   asyncio.get_running_loop().set_default_executor(executor)
   def bridge_fetch(data):
    with bridge.request('POST',upstream,headers={},body=data,timeout=10,connect_timeout=3,response_limit=1024) as r:return r.read()
   from io import BytesIO
   from ucloud_sandboxes.http_server import JsonHttpHandler
   loop=asyncio.get_running_loop()
   class Body:
    def __init__(self,req):self.req=req
    def read(self,n):return asyncio.run_coroutine_threadsafe(self.req.content.readexactly(n),loop).result()
   class HandlerBridge(JsonHttpHandler):
    def __init__(self,req):
     self.rfile=Body(req);self.wfile=BytesIO();self.headers=req.headers
     self._request_body_consumed=False;self._keep_alive_after_body=False
     self.command='POST';self.request_version='HTTP/1.1';self.requestline='POST / HTTP/1.1'
     self.response_headers={};self.close_connection=True
     self.do_POST()
    def send_response_only(self,code,message=None):self.response_status=code
    def send_header(self,key,value):self.response_headers[key]=value
    def end_headers(self):pass
    def do_POST(self):
     data=self._read_raw_body(max_bytes=1048576);body=bridge_fetch(data);self._write_bytes(body,'application/json')
   async with ClientSession(connector=TCPConnector(limit=512),auto_decompress=False) as client:
    async def post(req):
     if variant=='handler-bridge':
      handler=await asyncio.to_thread(HandlerBridge,req)
      response=web.Response(body=handler.wfile.getvalue(),status=handler.response_status,headers=handler.response_headers);response.force_close();return response
     data=await req.read()
     if variant=='async-bridge':body=await asyncio.to_thread(bridge_fetch,data)
     else:
      async with client.post(upstream,data=data,allow_redirects=False) as r:body=await r.read()
     response=web.Response(body=body,content_type='application/json');response.force_close();return response
    async def get(req):
     response=web.json_response({'cpu':time.process_time()});response.force_close();return response
    app=web.Application();app.router.add_post('/',post);app.router.add_get('/',get)
    runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();pipe.send(site._server.sockets[0].getsockname()[1]);await asyncio.Event().wait()
  asyncio.run(serve());return
 from ucloud_sandboxes.http_server import HighBacklogThreadingHTTPServer,JsonHttpHandler
 if variant=='urllib3':
  import urllib3
  pool=urllib3.PoolManager(maxsize=512,block=False,retries=False)
  def fetch(data):
   with pool.request('POST',upstream,body=data,preload_content=False) as r:return r.read()
 elif variant=='process':
  client=ProcessClient(upstream)
  fetch=client.fetch
 else:
  from ucloud_sandboxes.node_http_async import AsyncNodeHttpPool
  pool=AsyncNodeHttpPool(control_connections=512)
  def fetch(data):
   with pool.request('POST',upstream,headers={},body=data,timeout=10,connect_timeout=3,response_limit=1024) as r:return r.read()

 class Handler(JsonHttpHandler):
  allow_http_keep_alive=False
  def do_POST(self):
   body=self._read_raw_body(max_bytes=1048576);reply=fetch(body);self._write_bytes(reply,'application/json')
  def do_GET(self):
   cpu=time.process_time()
   if variant=='process':
    from pathlib import Path
    stat=Path(f'/proc/{client.child.pid}/stat').read_text().split()
    cpu+=(int(stat[13])+int(stat[14]))/os.sysconf('SC_CLK_TCK')
   self._write_json({'cpu':cpu})
 server=HighBacklogThreadingHTTPServer(('127.0.0.1',0),Handler,max_request_threads=1024)
 pipe.send(server.server_address[1]);server.serve_forever(poll_interval=.01)
async def load(url,concurrency,count):
 import aiohttp
 async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(limit=concurrency)) as client:
  async with client.get(url) as r:before=(await r.json())['cpu']
  gate=asyncio.Semaphore(concurrency);samples=[];body=b'x'*4096
  async def one():
   async with gate:
    start=time.monotonic()
    async with client.post(url,data=body) as r:
     assert r.status==200;assert (await r.json())=={'ok':True}
    samples.append(time.monotonic()-start)
  start=time.monotonic();await asyncio.gather(*(one() for _ in range(count)));elapsed=time.monotonic()-start
  async with client.get(url) as r:cpu=(await r.json())['cpu']-before
 return {'wall':elapsed,'gateway_cpu':cpu,'p50':statistics.median(samples),'p95':sorted(samples)[int(.95*len(samples))]}
if __name__=='__main__':
 ctx=multiprocessing.get_context('spawn');a,b=ctx.Pipe();p=ctx.Process(target=backend,args=(b,));p.start();port=a.recv();a.close();b.close()
 try:
  for variant in ('aiohttp','handler-bridge','async-bridge','async-front','async-front','async-bridge','handler-bridge','aiohttp'):
   a,b=ctx.Pipe();g=ctx.Process(target=gateway,args=(b,f'http://127.0.0.1:{port}/',variant));g.start();gp=a.recv();a.close();b.close()
   driver_cpus=sorted(os.sched_getaffinity(0))
   try:
    os.sched_setaffinity(0,driver_cpus[8:])
    print(json.dumps({'variant':variant,**asyncio.run(load(f'http://127.0.0.1:{gp}/',128,4096))}),flush=True)
   finally:
    os.sched_setaffinity(0,driver_cpus);g.terminate();g.join()
 finally:p.terminate();p.join()
