"""Compare blocking urllib3 with one aiohttp I/O loop behind the same HTTP handler."""
import asyncio,concurrent.futures,json,multiprocessing,os,sys,threading,time,statistics
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.request import Request

def pin(index):
 cpus=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,cpus[index:index+4])
def backend(pipe):
 pin(4)
 from aiohttp import web
 async def respond(req):
  body=await req.read();await asyncio.sleep(.01)
  return web.Response(body=b'{"ok":true}',content_type='application/json')
 async def run():
  app=web.Application();app.router.add_route('*','/{tail:.*}',respond)
  runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();pipe.send(site._server.sockets[0].getsockname()[1]);await asyncio.Event().wait()
 asyncio.run(run())
def gateway(pipe,upstream,variant):
 pin(0)
 from ucloud_sandboxes.http_server import HighBacklogThreadingHTTPServer,JsonHttpHandler
 if variant=='urllib3':
  import urllib3
  pool=urllib3.PoolManager(maxsize=512,block=False,retries=False)
  def fetch(data):
   with pool.request('POST',upstream,body=data,preload_content=False) as r:return r.read()
 else:
  from ucloud_sandboxes.node_http_async import AsyncNodeHttpPool
  pool=AsyncNodeHttpPool(control_connections=512)
  def fetch(data):
   with pool.request('POST',upstream,headers={},body=data,timeout=10,connect_timeout=3,response_limit=1024) as r:return r.read()

 class Handler(JsonHttpHandler):
  allow_http_keep_alive=False
  def do_POST(self):
   body=self._read_raw_body(max_bytes=1048576);reply=fetch(body);self._write_bytes(reply,'application/json')
  def do_GET(self):self._write_json({'cpu':time.process_time()})
 server=HighBacklogThreadingHTTPServer(('127.0.0.1',0),Handler,max_request_threads=1024)
 pipe.send(server.server_address[1]);server.serve_forever(poll_interval=.01)
async def load(url,concurrency,count):
 import aiohttp
 async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(limit=concurrency)) as client:
  async with client.get(url) as r:before=(await r.json())['cpu']
  gate=asyncio.Semaphore(concurrency);samples=[];body=b'x'*4096
  async def one():
   async with gate:
    start=time.monotonic()
    async with client.post(url,data=body) as r:
     assert r.status==200;assert (await r.json())=={'ok':True}
    samples.append(time.monotonic()-start)
  start=time.monotonic();await asyncio.gather(*(one() for _ in range(count)));elapsed=time.monotonic()-start
  async with client.get(url) as r:cpu=(await r.json())['cpu']-before
 return {'wall':elapsed,'gateway_cpu':cpu,'p50':statistics.median(samples),'p95':sorted(samples)[int(.95*len(samples))]}
if __name__=='__main__':
 ctx=multiprocessing.get_context('spawn');a,b=ctx.Pipe();p=ctx.Process(target=backend,args=(b,));p.start();port=a.recv();a.close();b.close()
 try:
  for variant in ('urllib3','aiohttp','urllib3','aiohttp'):
   a,b=ctx.Pipe();g=ctx.Process(target=gateway,args=(b,f'http://127.0.0.1:{port}/',variant));g.start();gp=a.recv();a.close();b.close()
   try:print(json.dumps({'variant':variant,**asyncio.run(load(f'http://127.0.0.1:{gp}/',128,4096))}),flush=True)
   finally:g.terminate();g.join()
 finally:p.terminate();p.join()
