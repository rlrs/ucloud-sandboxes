from pathlib import Path
import json,sqlite3,re,sys
run=sys.argv[1]
assert re.fullmatch(r'relay-load-[0-9a-f]{12}', run)
rows=[]
for registry in [Path('/var/lib/ucloud-sandboxes/node-state/direct-runtime/direct-registry.sqlite')]:
 with sqlite3.connect(registry.as_uri()+'?mode=ro',uri=True) as db:
  for sid,raw in db.execute('SELECT sandbox_id,record_json FROM registrations'):
   if not sid.startswith(run+'-'):raise RuntimeError('non-test sandbox present')
   item=json.loads(raw);container=item['container_id'];assert re.fullmatch('[0-9a-f]{64}',container)
   group=Path('/sys/fs/cgroup')/container
   if not group.exists():raise RuntimeError('test cgroup absent')
   quota,period=(group/'cpu.max').read_text().split();assert (quota,period)==('100000','100000')
   burst=group/'cpu.max.burst';before=burst.read_text().strip();assert before=='0'
   # Alternate indexes within each worker after sorting so placement is balanced.
   rows.append({'sandbox_id':sid,'group':str(group),'before':before})
rows.sort(key=lambda r:r['sandbox_id'])
try:
 for index,row in enumerate(rows):
  row['treatment']=index%2==0
  if row['treatment']:
   (Path(row['group'])/'cpu.max.burst').write_text('100000')
   assert (Path(row['group'])/'cpu.max.burst').read_text().strip()=='100000'
except BaseException:
 for row in rows:
  p=Path(row['group'])/'cpu.max.burst'
  if p.exists():p.write_text(row['before'])
 raise
print(json.dumps(rows))
